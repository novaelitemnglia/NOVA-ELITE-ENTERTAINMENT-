# NOVA ELITE ENTERTAINMENT — Website starter

A responsive, multi-page static website designed for free hosting with GitHub Pages.

## Included
- `index.html` — homepage
- `about.html` — company introduction
- `artists.html` — roster
- `artists/artist-01.html` — individual artist profile
- `artists/artist-02.html` — individual artist profile
- `artists/artist-03.html` — individual artist profile
- `discography.html`, `news.html`, `auditions.html`, `schedule.html`, `contact.html`
- `assets/style.css` — all styling and responsive layout
- `assets/script.js` — mobile navigation and current year

## Before publishing
1. Open the files in a text editor or GitHub's web editor.
2. Search for `YOUR ARTIST` and replace the sample artist names.
3. Update the artist descriptions, member counts, genres and release information in the three files inside `artists/`.
4. Replace the sample contact email and social handle in `contact.html`.
5. Replace sample news, schedule and discography entries with your own.
6. Optional: add your own images. The current artwork is made from CSS shapes and typography, so the site works without image uploads.

## Publish free with GitHub Pages
1. Sign in or create an account at https://github.com/.
2. Click **New repository**. For the simplest URL, name it `YOURUSERNAME.github.io` (replace YOURUSERNAME with your GitHub username). Set it to **Public**.
3. Upload the contents of this folder to the repository's root. Important: `index.html` must be at the top level, not inside another folder.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes. Your site should appear at `https://YOURUSERNAME.github.io`.

If you use a repository with a different name, your address will usually be `https://YOURUSERNAME.github.io/REPOSITORY-NAME/`. This starter uses relative links, so it also works as a project site.

## Editing later
- To change the color palette, edit the variables at the top of `assets/style.css`:
  - `--ink` = midnight navy
  - `--paper` = cloud white
  - `--sage` = ice blue
  - `--coral` = soft lilac
- To add another artist, copy `artists/artist-03.html`, rename the copy, edit its content, and add a matching card/link to `artists.html` and `index.html`.
- To add a new page, copy an existing top-level HTML page and update its title, active navigation item and content.

This is a static showcase website. It does not include a real login system, database, fan account system, or working form submissions. Do not put private information in public pages.
